

def show_print_message(message, show_info=True):
    """
    This function print message depending on show_info value
    :param message:
    :param show_info:
    :return:
    """
    if show_info is True:
        print(message)