"""
Deep Learning Utilities - Global exports
"""
from __future__ import absolute_import

from . import Definitions


