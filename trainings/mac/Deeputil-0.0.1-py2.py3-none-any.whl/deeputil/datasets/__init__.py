from __future__ import absolute_import

from . import TitanicList
from . import CreditCardCustomers
from . import AdultIncomeCensus
from . import USStatesZipCodes
from . import Iris
from . import Prostate
from . import Abalone
from . import WineQuality
from . import Arrhythmia
from . import AutoMpg
from . import Australia
from . import CitiBike
from . import Chicago
from . import Higgs
from . import Coil2000
from . import Diamonds
from . import Movies
from . import BreastCancer
from . import USCommunities
from . import Airline
from . import Emoji
from . import Seeds
from . import HousingPrices
from . import LendingClub
from . import AirQuality
from . import Walking






